package parcial_banco;

import java.util.Scanner;

public class Banco {

    private String Nombre;
    private final int MaxSedes = 5;
    private Sede[] sedes;
    static Scanner leer = new Scanner(System.in);

    public Banco() {
        this.sedes = new Sede[MaxSedes];
    }

    public Banco(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public Sede[] getSedes() {
        return sedes;
    }

    public void setSedes(Sede[] sedes) {
        this.sedes = sedes;
    }

    public static Scanner getLeer() {
        return leer;
    }

    public static void setLeer(Scanner leer) {
        Banco.leer = leer;
    }

    public void Crear_Sede() {
        String Nombre;
        String Direccion;
        String Ciudad;
        int Codigo;
        int Num_sedes;

        System.out.println("Ingrese el numero de sedes que desea crear: ");
        Num_sedes = leer.nextInt();
        if (Num_sedes > 5) {
            System.out.println("!No se puede crear mas de 5 sedes!");
        } else {

            for (int i = 0; i < Num_sedes; i++) {
                System.out.println("Escriba un nombre a la sede: ");
                Nombre = leer.next();
                System.out.println("Introduzca la direccion de la sede: ");
                Direccion = leer.next();
                System.out.println("Introduzca la ciudad en la que esta ubicada la sede:  ");
                Ciudad = leer.next();
                System.out.println("Escriba el codigo de la sede:  ");
                Codigo = leer.nextInt();
                sedes[i] = new Sede(Nombre,Direccion,Ciudad,Codigo);
            }
        }
    }

    public void Consultar_Sede() {
        int codigo;
        System.out.println("Ingrese el codigo de la sede que desea buscar: ");
        codigo = leer.nextInt();

        for (Sede sede : sedes) {
            if (sede.getCodigo() == codigo) {
                System.out.println("Búsqueda exitosa");
                System.out.println("Se ha encontrado su sede");
                System.out.println(sede);
            } else {
                System.out.println("No se encuentra registrado este código de sede");
            }
        }

    }

    public void Lista_Sedes() {
        System.out.println("Lista de las sedes: ");
        for (int i = 0; i < sedes.length; i++) {

            System.out.println(sedes[i]);
        }

    }

    public String toString() {
        return "\nNombre:  " + this.getNombre();

    }

}
