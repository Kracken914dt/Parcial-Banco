
package parcial_banco;

public class Cuenta {
    private int Num_Cuenta;
    private String Tipo_Cuenta;
    private double Saldo_Inicial;
    private double Saldo;
    private Persona Titular;

    public Cuenta(int Num_Cuenta, String Tipo_Cuenta, double Saldo_Inicial, double Saldo, Persona Titular) {
        this.Num_Cuenta = Num_Cuenta;
        this.Tipo_Cuenta = Tipo_Cuenta;
        this.Saldo_Inicial = Saldo_Inicial;
        this.Saldo = Saldo;
        this.Titular = Titular;
    }

    public int getNum_Cuenta() {
        return Num_Cuenta;
    }

    public void setNum_Cuenta(int Num_Cuenta) {
        this.Num_Cuenta = Num_Cuenta;
    }

    public String getTipo_Cuenta() {
        return Tipo_Cuenta;
    }

    public void setTipo_Cuenta(String Tipo_Cuenta) {
        this.Tipo_Cuenta = Tipo_Cuenta;
    }

    public double getSaldo_Inicial() {
        return Saldo_Inicial;
    }

    public void setSaldo_Inicial(double Saldo_Inicial) {
        this.Saldo_Inicial = Saldo_Inicial;
    }

    public double getSaldo() {
        return Saldo;
    }

    public void setSaldo(double Saldo) {
        this.Saldo = Saldo;
    }

    public Persona getTitular() {
        return Titular;
    }

    public void setTitular(Persona Titular) {
        this.Titular = Titular;
    }
    

    public String Mostrar_datos(){
        return "\n Numero de la cuenta:  " + this.getNum_Cuenta() + "\n Tipo de cuenta: " + this.getTipo_Cuenta() + "\n Saldo inicial: " + this.getSaldo_Inicial() + "\n Saldo: " + this.getSaldo() + "\n Titular de la cuenta: " + this.getTitular();
        
    }
    
    
}
